import dash
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
import pandas as pd
from scipy.stats import norm, skew, kurtosis

from mom_strat_new import Indicators
from data_handler import sql_dbs

# =========================
# Strategy weights
# =========================
strat_weights = {
    "mom_1,4":  [0.25,0.25,0.25,0.25,0,0,0,0,0,0,0,0],
    "mom_5,8":  [0,0,0,0,0.25,0.25,0.25,0.25,0,0,0,0],
    "mom_9,11": [0,0,0,0,0,0,0,0,0.334,0.333,0.333,0]
}

# =========================
# Build indicators_dbs
# =========================
indicators_dbs = {}

for market_index in sql_dbs.keys():
    indicators_dbs[market_index] = {}
    for sec in sql_dbs[market_index].keys():
        ind = Indicators(market_index, sec)
        for name, w in strat_weights.items():
            ind.calc_mom_indicators(name=name, weights=w, periodicity="daily")
        indicators_dbs[market_index][sec] = ind.data.tail(250)

# =========================
# PDF traces
# =========================
def pdf_traces(df, label):
    # Ensure numeric
    returns = pd.to_numeric(df["daily_ret"], errors="coerce").dropna()
    if len(returns) < 2:
        return []

    # Separate positive and negative returns
    pos = returns[returns > 0]
    neg = returns[returns < 0]

    # Full x-axis covering both positive and negative returns
    x_min = returns.min() * 1.2
    x_max = returns.max() * 1.2
    x = np.linspace(x_min, x_max, 1000)

    traces = []

    # Positive distribution
    if len(pos) > 5:
        mu, sd = norm.fit(pos)
        pdf_pos = norm.pdf(x, mu, sd)
        traces.append(go.Scatter(
            x=x, y=pdf_pos,
            fill='tozeroy',
            line=dict(color='green', width=2),
            name=f"{label} Positive",
            hovertemplate=f"μ={mu:.4f}<br>σ={sd:.4f}<br>skew={skew(pos):.2f}<br>kurt={kurtosis(pos):.2f}",
            opacity=0.3
        ))

    # Negative distribution
    if len(neg) > 5:
        mu, sd = norm.fit(neg)
        pdf_neg = norm.pdf(x, mu, sd)
        traces.append(go.Scatter(
            x=x, y=pdf_neg,
            fill='tozeroy',
            line=dict(color='red', width=2),
            name=f"{label} Negative",
            hovertemplate=f"μ={mu:.4f}<br>σ={sd:.4f}<br>skew={skew(neg):.2f}<br>kurt={kurtosis(neg):.2f}",
            opacity=0.3
        ))

    return traces




# =========================
# Create figure
# =========================
def create_figure(df, sec):
    fig = make_subplots(
        rows=5, cols=1,
        vertical_spacing=0.0375,
        subplot_titles=[
            "Close",
            "Daily Returns",
            "Momentum Z-score (1,4)",
            "Volatility Past 30 Days",
            "Distribution of Daily Returns"
        ]
    )

    fig.add_trace(go.Scatter(x=df.index, y=df["Close"], name="Close"), 1, 1)
    fig.add_trace(go.Scatter(x=df.index, y=df["daily_ret"], name="daily_ret"), 2, 1)
    fig.add_trace(go.Scatter(x=df.index, y=df["mom_1,4_z"], name="mom_1,4_z"), 3, 1)
    fig.add_trace(go.Scatter(x=df.index, y=df["period_std_dev_t-1"], name="vol"), 4, 1)

    # Buy / Sell signals
    buy = df[df["buy/sell_mom_1,4"] == "buy"]
    sell = df[df["buy/sell_mom_1,4"] == "sell"]

    fig.add_trace(go.Scatter(
        x=buy.index, y=buy["Close"],
        mode="markers",
        marker=dict(color="green", symbol="triangle-up", size=14),
        name="Buy"
    ), 1, 1)

    fig.add_trace(go.Scatter(
        x=sell.index, y=sell["Close"],
        mode="markers",
        marker=dict(color="red", symbol="triangle-down", size=14),
        name="Sell"
    ), 1, 1)

    # PDF subplot
    for t in pdf_traces(df, sec):
        fig.add_trace(t, 5, 1)

    # Horizontal Z-score lines
    for z in [1,1.25,1.5,1.75,-1,-1.25,-1.5,-1.75]:
        fig.add_hline(y=z, row=3, col=1, line_dash="dash", opacity=0.4)

    # Axes
    x_range = [df.index.min(), df.index.max()]
    for r in range(1,5):
        fig.update_xaxes(range=x_range, row=r, col=1)
    for r in range(1,4):
        fig.update_xaxes(showticklabels=False, row=r, col=1)

    fig.update_layout(
        template="plotly_white",
        height=1400,
        margin=dict(l=80, r=80, t=120, b=60),
        title=f"{sec}"
    )

    return fig

# =========================
# Dash App
# =========================
app = dash.Dash(__name__)

markets = list(indicators_dbs.keys())
default_market = markets[0]
default_stock = list(indicators_dbs[default_market].keys())[0]

app.layout = html.Div([
    html.H1("Momentum Strategy Dashboard", style={"textAlign":"center"}),

    html.Div([
        # Sidebar
        html.Div([
            html.H3("Index"),
            dcc.Dropdown(
                id="index-dropdown",
                options=[{"label":i, "value":i} for i in markets],
                value=default_market,
                clearable=False
            ),
            html.Br(),
            html.H3("Stock"),
            dcc.Dropdown(id="stock-dropdown", clearable=False)
        ], style={
            "width":"20%",
            "padding":"20px",
            "backgroundColor":"#f5f5f5",
            "borderRadius":"10px"
        }),

        # Graph
        html.Div([
            dcc.Graph(id="main-graph")
        ], style={"width":"75%", "paddingLeft":"30px"})
    ], style={"display":"flex","justifyContent":"center","width":"95%","margin":"auto"})
])

# =========================
# Callbacks
# =========================
@app.callback(
    Output("stock-dropdown", "options"),
    Output("stock-dropdown", "value"),
    Input("index-dropdown", "value")
)
def update_stock_dropdown(index):
    stocks = list(indicators_dbs[index].keys())
    return [{"label":s, "value":s} for s in stocks], stocks[0]

@app.callback(
    Output("main-graph", "figure"),
    Input("index-dropdown", "value"),
    Input("stock-dropdown", "value")
)
def update_graph(index, stock):
    df = indicators_dbs[index][stock]
    return create_figure(df, stock)

# =========================
# Run
# =========================
if __name__ == "__main__":
    app.run(debug=True)
